#import <React/RCTBridgeModule.h>

@interface RCT_EXTERN_MODULE(AdchainSdk, NSObject)

RCT_EXTERN_METHOD(initialize:(NSString *)appKey
                  appSecret:(NSString *)appSecret
                  environment:(NSString *)environment
                  resolver:(RCTPromiseResolveBlock)resolver
                  rejecter:(RCTPromiseRejectBlock)rejecter)

RCT_EXTERN_METHOD(login:(NSString *)userId
                  gender:(NSString *)gender
                  birthYear:(nonnull NSNumber *)birthYear
                  resolver:(RCTPromiseResolveBlock)resolver
                  rejecter:(RCTPromiseRejectBlock)rejecter)

RCT_EXTERN_METHOD(isLoggedIn:(RCTPromiseResolveBlock)resolver
                  rejecter:(RCTPromiseRejectBlock)rejecter)

RCT_EXTERN_METHOD(logout:(RCTPromiseResolveBlock)resolver
                  rejecter:(RCTPromiseRejectBlock)rejecter)

@end