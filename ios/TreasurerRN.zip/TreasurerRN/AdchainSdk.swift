import Foundation
import React
import AdchainSDK

@objc(AdchainSdk)
class AdchainSdkModule: NSObject {
  @objc static func requiresMainQueueSetup() -> Bool { true }

  // initialize(appKey, appSecret, environment?) -> iOS SDK의 initialize(application:sdkConfig:) 호출
  @objc func initialize(_ appKey: NSString,
                        appSecret: NSString,
                        environment: NSString?,
                        resolver: @escaping RCTPromiseResolveBlock,
                        rejecter: @escaping RCTPromiseRejectBlock) {
    DispatchQueue.main.async {
      let env: AdchainSdkConfig.Environment = {
        guard let envString = environment as String? else { return .production }
        switch envString.uppercased() {
          case "STAGING": return .staging
          case "DEVELOPMENT": return .development
          default: return .production
        }
      }()
      
      let cfg = AdchainSdkConfig.Builder(appKey: appKey as String, appSecret: appSecret as String)
        .setEnvironment(env)
        .setTimeout(30.0)
        .build()
      AdchainSDK.AdchainSdk.shared.initialize(application: UIApplication.shared, sdkConfig: cfg)
      resolver(nil)
    }
  }

  // login(userId, gender?, birthYear?) -> AdchainSdkUser 생성 후 로그인
  @objc func login(_ userId: NSString,
                   gender: NSString?,
                   birthYear: NSNumber?,
                   resolver: @escaping RCTPromiseResolveBlock,
                   rejecter: @escaping RCTPromiseRejectBlock) {
    let g: AdchainSdkUser.Gender? = {
      guard let s = gender as String? else { return nil }
      switch s.lowercased() {
        case "male", "m": return .male
        case "female", "f": return .female
        default: return nil
      }
    }()

    let user = AdchainSdkUser(userId: userId as String, gender: g, birthYear: birthYear?.intValue)

    AdchainSDK.AdchainSdk.shared.login(adchainSdkUser: user, listener: AdchainSdkLoginListenerWrapper(
      onSuccess: {
        resolver(true)
      }, onFailure: { err in
        rejecter("LOGIN_ERROR", "Login failed: \(err.description)", nil)
      }
    ))
  }

  @objc func isLoggedIn(_ resolver: @escaping RCTPromiseResolveBlock,
                        rejecter: @escaping RCTPromiseRejectBlock) {
    resolver(AdchainSDK.AdchainSdk.shared.isLoggedIn)
  }

  @objc func logout(_ resolver: @escaping RCTPromiseResolveBlock,
                    rejecter: @escaping RCTPromiseRejectBlock) {
    AdchainSDK.AdchainSdk.shared.logout()
    resolver(nil)
  }
}

// Swift 클로저를 iOS 리스너 프로토콜로 감싸는 헬퍼
class AdchainSdkLoginListenerWrapper: NSObject, AdchainSdkLoginListener {
  private let onSuccessBlock: () -> Void
  private let onFailureBlock: (AdchainLoginError) -> Void
  
  init(onSuccess: @escaping () -> Void, onFailure: @escaping (AdchainLoginError) -> Void) {
    self.onSuccessBlock = onSuccess
    self.onFailureBlock = onFailure
  }
  
  func onSuccess() { 
    onSuccessBlock() 
  }
  
  func onFailure(_ error: AdchainLoginError) { 
    onFailureBlock(error) 
  }
}